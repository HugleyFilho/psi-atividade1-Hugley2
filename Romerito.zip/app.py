from flask import Flask, render_template
import models

app = Flask(__name__)
app.secret_key = 'hugulei'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/livro')
def livro():
    return render_template('livro.html')